package booleanoo.operators;

/**
 * A boolean operator.
 */
public interface BooleanOperator {
    public String toString ();
    public boolean equals (Object other);
}
